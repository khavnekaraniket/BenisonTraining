

// import React, { useState } from 'react';
// import EditModal from './EditModal'; 

// function Registration() {
//   const [formData, setFormData] = useState({
//     firstName: '',
//     lastName: '',
//     age :'',
//     gender:'',
//     contactNo: '',
//     country: '',
//     state: '',
//     city: '',
//     address: '',
//     agree: false
//   });

//   const [submitted, setSubmitted] = useState(false);
//   const [editIndex, setEditIndex] = useState(null);
//   const [editFormData, setEditFormData] = useState({ ...formData });
//   const [isEditModalOpen, setIsEditModalOpen] = useState(false); 

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     if (editIndex !== null) {
//       const updatedData = [...tableData];
//       updatedData[editIndex] = editFormData;
//       setTableData(updatedData);
//       setEditIndex(null);
//     } else {
//       setTableData([...tableData, { ...formData }]);
//     }
//     setSubmitted(true);
//     setIsEditModalOpen(false); 
//   };

//   const handleChange = (e) => {
//     const { name, value, type, checked } = e.target;
//     setFormData(prevState => ({
//       ...prevState,
//       [name]: type === 'checkbox' ? checked : value
//     }));
//   };

//   const handleEdit = (index) => {
//     setEditIndex(index);
//     setEditFormData(tableData[index]);
//     setIsEditModalOpen(true); 
//   };

//   const handleDelete = (index) => {
//     const updatedData = [...tableData];
//     updatedData.splice(index, 1);
//     setTableData(updatedData);
//   };

//   const [tableData, setTableData] = useState([]);

//   return (
//     <div>
//       <h1>Registration page</h1>
//       <form className="row g-3 needs-validation" noValidate onSubmit={handleSubmit}>
//         {/* First Name */}
//         <div className="col-md-4">
//           <label htmlFor="validationCustom01" className="form-label">First name</label>
//           <input type="text" className="form-control" id="validationCustom01" name="firstName" value={formData.firstName} onChange={handleChange} required />
           
//          </div>
//          {/* Last name */}
//          <div className="col-md-4">
//           <label htmlFor="validationCustom02" className="form-label">Last name</label>
//           <input type="text" className="form-control" id="validationCustom02" name="lastName" value={formData.lastName} onChange={handleChange} required />
          
//          </div>
//          {/* age */}
//          <div className="col-md-4">
//           <label htmlFor="validationCustom03" className="form-label">Age</label>
//           <input type="number" className="form-control" id="validationCustom03" name="age" value={formData.age} onChange={handleChange} required />
          
//         </div>
//         <div className="col-md-4">
//           <label htmlFor="gender" className="form-label">Gender</label>
//           <div className="btn-group" role="group" aria-label="Basic radio toggle button group">
//             <input type="radio" className="btn-check" name="gender" id="male" value="male" checked={formData.gender === "male"} onChange={handleChange} />
//             <label className="btn btn-outline-primary" htmlFor="male">Male</label>

//             <input type="radio" className="btn-check" name="gender" id="female" value="female" checked={formData.gender === "female"} onChange={handleChange} />
//             <label className="btn btn-outline-primary" htmlFor="female">Female</label>

//             <input type="radio" className="btn-check" name="gender" id="transgender" value="transgender" checked={formData.gender === "transgender"} onChange={handleChange} />
//             <label className="btn btn-outline-primary" htmlFor="transgender">Transgender</label>
//           </div>
//         </div>

//         {/* Contact No */}
//         <div className="col-md-4">
//           <label htmlFor="validationCustom04" className="form-label">Contact No</label>
//           <input type="text" className="form-control" id="validationCustom04" name="contactNo" value={formData.contactNo} onChange={handleChange} required />
         
//         </div>
//         {/* Country */}
//         <div className="col-md-4">
//           <label htmlFor="validationCustom05" className="form-label">Country</label>
//           <input type="text" className="form-control" id="validationCustom05" name="country" value={formData.country} onChange={handleChange} required />
          
//         </div>
//         {/* State */}
//         <div className="col-md-4">
//           <label htmlFor="validationCustom06" className="form-label">State</label>
//           <input type="text" className="form-control" id="validationCustom06" name="state" value={formData.state} onChange={handleChange} required />
          
//         </div>
//         {/* City */}
//         <div className="col-md-4">
//           <label htmlFor="validationCustom07" className="form-label">City</label>
//           <input type="text" className="form-control" id="validationCustom07" name="city" value={formData.city} onChange={handleChange} required />
          
//         </div>
//         {/* Address */}
//         <div className="col-md-8">
//           <label htmlFor="validationCustom08" className="form-label">Address</label>
//           <input type="text" className="form-control" id="validationCustom08" name="address" value={formData.address} onChange={handleChange} required />
          
//         </div>
        

//         <button className="btn btn-primary" type="submit">Submit form</button>
//       </form>

      
//       {submitted && (
//         <div>
//           <h2>Form Data:</h2>
//           <table className="table">
//             <thead>
//               <tr>
//                 <th>SNo</th>
//                 <th>First Name</th>
//                 <th>Last Name</th>
//                 <th>Age</th>
//                 <th>Gender</th>
//                 <th>Country</th>
//                 <th>City</th>
                
//               </tr>
//             </thead>
//             <tbody>
//               {tableData.map((data, index) => (
//                 <tr key={index}>
//                   <td>{index + 1}</td>
//                   <td>{data.firstName}</td>
//                   <td>{data.lastName}</td>
//                   <td>{data.age}</td>
//                   <td>{data.gender}</td>
//                   <td>{data.country}</td>
//                   <td>{data.city}</td>
//                   <td></td>
                  
//                   <td>
//                     <button className="btn btn-primary" onClick={() => handleEdit(index)}>Edit</button>
//                     <button className="btn btn-danger" onClick={() => handleDelete(index)}>Delete</button>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       )}

      
//       <EditModal
//         isOpen={isEditModalOpen}
//         onClose={() => setIsEditModalOpen(false)}
//         formData={editFormData}
//         handleChange={(e) => setEditFormData({ ...editFormData, [e.target.name]: e.target.value })}
//         handleSubmit={handleSubmit}
//       />
//     </div>
//   );
// }

// export default Registration;

import React, { useState } from 'react';
import EditModal from './EditModal'; 

function Registration() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    age: '',
    gender: '',
    contactNo: '',
    country: '',
    state: '',
    city: '',
    address: '',
    agree: false
  });

  const [submitted, setSubmitted] = useState(false);
  const [editIndex, setEditIndex] = useState(null);
  const [editFormData, setEditFormData] = useState({ ...formData });
  const [isEditModalOpen, setIsEditModalOpen] = useState(false); 

  const handleSubmit = (e) => {
    e.preventDefault();
    // Custom validation logic
    if (!formData.firstName || !formData.lastName || !formData.age || !formData.gender || !formData.contactNo || !formData.country || !formData.state || !formData.city || !formData.address) {
      alert('Please fill in all required fields.');
      return;
    }
    if (!validatePhoneNumber(formData.contactNo)) {
      alert('Please enter a valid contact number.');
      return;
    }
    if (!validateAge(formData.age)) {
      alert('Please enter a valid age.');
      return;
    }
    if (!validateGender(formData.gender)) {
      alert('Please select a gender.');
      return;
    }
    // Handle form submission
    if (editIndex !== null) {
      const updatedData = [...tableData];
      updatedData[editIndex] = editFormData;
      setTableData(updatedData);
      setEditIndex(null);
    } else {
      setTableData([...tableData, { ...formData }]);
    }
    setSubmitted(true);
    setIsEditModalOpen(false); 
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleEdit = (index) => {
    setEditIndex(index);
    setEditFormData(tableData[index]);
    setIsEditModalOpen(true); 
  };

  const handleDelete = (index) => {
    const updatedData = [...tableData];
    updatedData.splice(index, 1);
    setTableData(updatedData);
  };

  const [tableData, setTableData] = useState([]);

  // Validation functions
  const validatePhoneNumber = (phoneNumber) => {
    const regex = /^[0-9]{10}$/;
    return regex.test(phoneNumber);
  };

  const validateAge = (age) => {
    return parseInt(age) > 0 && parseInt(age) < 150;
  };

  const validateGender = (gender) => {
    return ['male', 'female', 'transgender'].includes(gender.toLowerCase());
  };

  return (
    <div>
      <h1>Registration page</h1>
      <form className="row g-3 needs-validation" noValidate onSubmit={handleSubmit}>
        {/* Form inputs */}
        {/* First Name */}
        <div className="col-md-4">
          <label htmlFor="validationCustom01" className="form-label">First name</label>
          <input type="text" className="form-control" id="validationCustom01" name="firstName" value={formData.firstName} onChange={handleChange} required />
        </div>
        {/* Last name */}
        <div className="col-md-4">
          <label htmlFor="validationCustom02" className="form-label">Last name</label>
          <input type="text" className="form-control" id="validationCustom02" name="lastName" value={formData.lastName} onChange={handleChange} required />
        </div>
        {/* Age */}
        <div className="col-md-4">
          <label htmlFor="validationCustom03" className="form-label">Age</label>
          <input type="number" className="form-control" id="validationCustom03" name="age" value={formData.age} onChange={handleChange} required />
        </div>
        {/* Gender */}
        <div className="col-md-4">
          <label htmlFor="gender" className="form-label">Gender</label>
          <div className="btn-group" role="group" aria-label="Basic radio toggle button group">
            <input type="radio" className="btn-check" name="gender" id="male" value="male" checked={formData.gender === "male"} onChange={handleChange} />
            <label className="btn btn-outline-primary" htmlFor="male">Male</label>
            <input type="radio" className="btn-check" name="gender" id="female" value="female" checked={formData.gender === "female"} onChange={handleChange} />
            <label className="btn btn-outline-primary" htmlFor="female">Female</label>
            <input type="radio" className="btn-check" name="gender" id="transgender" value="transgender" checked={formData.gender === "transgender"} onChange={handleChange} />
            <label className="btn btn-outline-primary" htmlFor="transgender">Transgender</label>
          </div>
        </div>
        {/* Contact No */}
        <div className="col-md-4">
          <label htmlFor="validationCustom04" className="form-label">Contact No</label>
          <input type="text" className="form-control" id="validationCustom04" name="contactNo" value={formData.contactNo} onChange={handleChange} required />
        </div>
                {/* Country */}
                <div className="col-md-4">
          <label htmlFor="validationCustom05" className="form-label">Country</label>
          <input type="text" className="form-control" id="validationCustom05" name="country" value={formData.country} onChange={handleChange} required />
        </div>
        {/* State */}
        <div className="col-md-4">
          <label htmlFor="validationCustom06" className="form-label">State</label>
          <input type="text" className="form-control" id="validationCustom06" name="state" value={formData.state} onChange={handleChange} required />
        </div>
        {/* City */}
        <div className="col-md-4">
          <label htmlFor="validationCustom07" className="form-label">City</label>
          <input type="text" className="form-control" id="validationCustom07" name="city" value={formData.city} onChange={handleChange} required />
        </div>
        {/* Address */}
        <div className="col-md-8">
          <label htmlFor="validationCustom08" className="form-label">Address</label>
          <input type="text" className="form-control" id="validationCustom08" name="address" value={formData.address} onChange={handleChange} required />
        </div>

        <button className="btn btn-primary" type="submit">Submit form</button>
      </form>

      {/* Display submitted data */}
      {submitted && (
        <div>
          <h2>Form Data:</h2>
          <table className="table">
            <thead>
              <tr>
                <th>SNo</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Age</th>
                <th>Gender</th>
                <th>Contact No</th>
                <th>Country</th>
                <th>State</th>
                <th>City</th>
                <th>Address</th>
              </tr>
            </thead>
            <tbody>
              {tableData.map((data, index) => (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>{data.firstName}</td>
                  <td>{data.lastName}</td>
                  <td>{data.age}</td>
                  <td>{data.gender}</td>
                  <td>{data.contactNo}</td>
                  <td>{data.country}</td>
                  <td>{data.state}</td>
                  <td>{data.city}</td>
                  <td>{data.address}</td>
                  <td></td>
                  <td>
                     <button className="btn btn-primary" onClick={() => handleEdit(index)}>Edit</button>
                     <button className="btn btn-danger" onClick={() => handleDelete(index)}>Delete</button>
                   </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      
      <EditModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        formData={editFormData}
        handleChange={(e) => setEditFormData({ ...editFormData, [e.target.name]: e.target.value })}
        handleSubmit={handleSubmit}
      />
    </div>
  );
}

export default Registration;

